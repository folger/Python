from distutils.core import setup

setup(
    name        = 'FolsTools',
    version     = '1.0.0',
    py_modules  = ['FolsTools'],
    author      = 'Folger',
    author_email= 'folger6@gmail.com',
    url         = '',
    description = "Folger's frequent use tools",
    )
